///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>
#include <glm/gtx/string_cast.hpp>

// declare the global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_NormalMatrixName = "normalMatrix";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
    m_loadedTextures = 0;

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
    // clear the allocated memory
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
    // destroy the created OpenGL textures
    DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width, height, colorChannels;
    GLuint textureID = 0;
    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);
    if (!image)
    {
        std::cout << "Could not load image: " << filename << std::endl;
        return false;
    }

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    if (colorChannels == 3)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    else if (colorChannels == 4)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    m_textureIDs[m_loadedTextures].ID = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    return true;
}

/***********************************************************
 *  SetTransformations() - Sets object transformations
 ***********************************************************/
void SceneManager::SetTransformations(glm::vec3 scaleXYZ, float XrotationDegrees, float YrotationDegrees, float ZrotationDegrees, glm::vec3 positionXYZ)
{
    glm::mat4 model = glm::translate(positionXYZ) * glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f)) *
        glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f)) *
        glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f)) *
        glm::scale(scaleXYZ);

    glm::mat3 normalMatrix = glm::transpose(glm::inverse(glm::mat3(model)));

    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, model);
        m_pShaderManager->setMat3Value(g_NormalMatrixName, normalMatrix);
    }
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method sets up the general lighting in the scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // Directional Light
    m_pShaderManager->setVec3Value("directionalLight.direction", -0.05f, -0.3f, -0.1f);
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.02f, 0.02f, 0.02f);
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.4f, 0.4f, 0.4f);
    m_pShaderManager->setVec3Value("directionalLight.specular", 0.0f, 0.0f, 0.0f);
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);

    // Point Light
    m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(-1.7f, 6.4f, 1.0f)); 

    m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.2f, 0.2f, 0.15f));  
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.5f, 1.3f, 1.0f));   
    m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.0f, 1.0f, 1.0f));   

    // Light Attenuation Factors
    m_pShaderManager->setFloatValue("pointLights[0].constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[0].linear", 0.15f);   // Controls light spread
    m_pShaderManager->setFloatValue("pointLights[0].quadratic", 0.045f); // Controls falloff

    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}



/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return(textureSlot);
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    // variables for this method
    glm::vec4 currentColor;

    currentColor.r = redColorValue;
    currentColor.g = greenColorValue;
    currentColor.b = blueColorValue;
    currentColor.a = alphaValue;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
    std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureID = -1;
        textureID = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager != NULL)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}


/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    /*** STUDENTS - add the code BELOW for defining object materials. ***/
    /*** There is no limit to the number of object materials that can ***/
    /*** be defined. Refer to the code in the OpenGL Sample for help  ***/
    // Table Material (Wood)
    OBJECT_MATERIAL tableMaterial;
    tableMaterial.diffuseColor = glm::vec3(0.7f, 0.5f, 0.3f); 
    tableMaterial.specularColor = glm::vec3(0.3f, 0.2f, 0.1f);
    tableMaterial.shininess = 32.0f;
    tableMaterial.tag = "table";
    m_objectMaterials.push_back(tableMaterial);

    // Table Leg (Stainless Steel)
    OBJECT_MATERIAL legMaterial;
    legMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f); 
    legMaterial.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
    legMaterial.shininess = 100.0f;
    legMaterial.tag = "leg";
    m_objectMaterials.push_back(legMaterial);

    // Matte Black Material (Base of Table and Lamp)
    OBJECT_MATERIAL blackMaterial;
    blackMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f); 
    blackMaterial.specularColor = glm::vec3(0.8f, 0.6f, 0.6f);
    blackMaterial.shininess = 10.0f;
    blackMaterial.tag = "black";
    m_objectMaterials.push_back(blackMaterial);

    // Lamp Shade Material
    OBJECT_MATERIAL lampShadeMaterial;
    lampShadeMaterial.diffuseColor = glm::vec3(1.9f, 1.8f, 1.7f); 
    lampShadeMaterial.specularColor = glm::vec3(1.5f, 1.5f, 1.5f);
    lampShadeMaterial.shininess = 10.0f;
    lampShadeMaterial.tag = "shade";
    m_objectMaterials.push_back(lampShadeMaterial);

    // Coffee Mug Material
    OBJECT_MATERIAL cupMaterial;
    cupMaterial.diffuseColor = glm::vec3(0.9f, 0.8f, 0.7f); 
    cupMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
    cupMaterial.shininess = 50.0f;
    cupMaterial.tag = "cup";
    m_objectMaterials.push_back(cupMaterial);

    // Books Covers
    OBJECT_MATERIAL book1Material;
    book1Material.diffuseColor = glm::vec3(0.5f, 0.2f, 0.2f); 
    book1Material.specularColor = glm::vec3(0.3f, 0.1f, 0.1f);
    book1Material.shininess = 15.0f;
    book1Material.tag = "book1";
    m_objectMaterials.push_back(book1Material);

    OBJECT_MATERIAL book2Material;
    book2Material.diffuseColor = glm::vec3(0.2f, 0.4f, 0.6f); 
    book2Material.specularColor = glm::vec3(0.2f, 0.2f, 0.3f);
    book2Material.shininess = 15.0f;
    book2Material.tag = "book2";
    m_objectMaterials.push_back(book2Material);

    OBJECT_MATERIAL book3Material;
    book3Material.diffuseColor = glm::vec3(0.4f, 0.3f, 0.1f); 
    book3Material.specularColor = glm::vec3(0.2f, 0.2f, 0.1f);
    book3Material.shininess = 15.0f;
    book3Material.tag = "book3";
    m_objectMaterials.push_back(book3Material);

    OBJECT_MATERIAL book4Material;
    book4Material.diffuseColor = glm::vec3(0.7f, 0.6f, 0.2f); 
    book4Material.specularColor = glm::vec3(0.3f, 0.3f, 0.1f);
    book4Material.shininess = 15.0f;
    book4Material.tag = "book4";
    m_objectMaterials.push_back(book4Material);

    // Book Pages (Paper Texture)
    OBJECT_MATERIAL pageMaterial;
    pageMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.8f); 
    pageMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
    pageMaterial.shininess = 5.0f;
    pageMaterial.tag = "page";
    m_objectMaterials.push_back(pageMaterial);

    // Floor Tile
    OBJECT_MATERIAL floorMaterial;
    floorMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f); 
    floorMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
    floorMaterial.shininess = 80.0f;
    floorMaterial.tag = "floor";
    m_objectMaterials.push_back(floorMaterial);
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for setting the material properties
 *  into the shader for the next draw command.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL material;
    bool bFound = FindMaterial(materialTag, material);

    if (bFound)
    {
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
    else
    {
        std::cout << "Material not found: " << materialTag << std::endl;
    }
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for finding a material in the
 *  materials list by its tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (const auto& mat : m_objectMaterials)
    {
        if (mat.tag == tag)
        {
            material = mat;
            return true;
        }
    }
    return false;
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    bool bReturn;

    bReturn = CreateGLTexture(
        "textures/woodtexture.jpg",
        "table");

    bReturn = CreateGLTexture(
        "textures/stainless.jpg",
        "leg");

    bReturn = CreateGLTexture(
        "textures/matteblack.jpg",
        "black");

    bReturn = CreateGLTexture(
        "textures/lamp.jpg",
        "shade");

    bReturn = CreateGLTexture(
        "textures/coffee.jpg",
        "cup");

    bReturn = CreateGLTexture(
        "textures/bookcover1.jpg",
        "book1");

    bReturn = CreateGLTexture(
        "textures/bookcover2.jpg",
        "book2");

    bReturn = CreateGLTexture(
        "textures/bookcover3.jpg",
        "book3");

    bReturn = CreateGLTexture(
        "textures/bookcover4.jpg",
        "book4");

    bReturn = CreateGLTexture(
        "textures/pages.jpg",
        "page");

    bReturn = CreateGLTexture(
        "textures/tile.jpg",
        "floor");

    BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Define materials before rendering
    DefineObjectMaterials();

    // Load the textures for the 3D scene
    LoadSceneTextures();

    // Set up scene lights
    SetupSceneLights();

    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTorusMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadSphereMesh();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
    // declare the variables for the transformations
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    /*** Set needed transformations before drawing the basic mesh.  ***/
    /*** This same ordering of code should be used for transforming ***/
    /*** and drawing all the basic 3D shapes.						***/
    /******************************************************************/
    // set the XYZ scale for the mesh
    scaleXYZ = glm::vec3(10.0f, 1.0f, 10.0f);

    // set the XYZ rotation for the mesh
    XrotationDegrees = 0.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;

    // set the XYZ position for the mesh
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

    // set the transformations into memory to be used on the drawn meshes
    SetTransformations(
        scaleXYZ,
        XrotationDegrees,
        YrotationDegrees,
        ZrotationDegrees,
        positionXYZ);

    // draw the mesh with transformation values
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("floor");
    SetShaderTexture("floor");
    SetTextureUVScale(10.0, 10.0);
    m_basicMeshes->DrawPlaneMesh();

    /****************************************************************/
    /****************************************************************/
    //TABLE START
    /****************************************************************/
    /****************************************************************/
    // Cylinder 1 (Table Top)
    scaleXYZ = glm::vec3(5.0f, 0.2f, 5.0f);
    positionXYZ = glm::vec3(0.0f, 4.2f, 0.0f);
    XrotationDegrees = 360.0f; // puts cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("table");
    SetShaderTexture("table");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh();

    // Cylinder 2 (Table Leg)
    scaleXYZ = glm::vec3(0.2f, 4.2f, 0.2f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    XrotationDegrees = 360.0f; // puts cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("leg");
    SetShaderTexture("leg");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh();

    // Cylinder 3 (Table Base)
    scaleXYZ = glm::vec3(1.0f, 0.2f, 1.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    XrotationDegrees = 360.0f; // puts cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("black");
    SetShaderTexture("black");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh();
    /****************************************************************/
    /****************************************************************/
    //TABLE END
    /****************************************************************/
    /****************************************************************/

    /****************************************************************/
    /****************************************************************/
    //LAMP START
    /****************************************************************/
    /****************************************************************/
    // Cylinder 1 (Lamp Base)
    scaleXYZ = glm::vec3(1.0f, 0.2f, 1.0f);
    positionXYZ = glm::vec3(-1.7f, 4.4f, 1.0f);
    XrotationDegrees = 360.0f; // puts cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("black");
    SetShaderTexture("black");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh();

    // Cylinder 2 (Lamp Leg)
    scaleXYZ = glm::vec3(0.1f, 3.2f, 0.1f);
    positionXYZ = glm::vec3(-1.7f, 4.4f, 1.0f);
    XrotationDegrees = 360.0f; // puts cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("black");
    SetShaderTexture("black");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh();

    // Tapered Cylinder 1 (Lamp Shade)
    scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
    positionXYZ = glm::vec3(-1.7f, 6.4f, 1.0f);
    XrotationDegrees = 360.0f; // puts tapered cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("shade");
    SetShaderTexture("shade");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawTaperedCylinderMesh();

    // Cylinder 3 (Lamp Cord)
    scaleXYZ = glm::vec3(0.01f, 0.9f, 0.01f);
    positionXYZ = glm::vec3(-1.2f, 5.4f, 1.0f);
    XrotationDegrees = 360.0f; // puts cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("black");
    SetShaderTexture("black");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh();

    // Sphere 1 (Lamp Cord End)
    scaleXYZ = glm::vec3(0.1f, 0.1f, 0.1f);
    positionXYZ = glm::vec3(-1.2f, 5.4f, 1.0f);
    XrotationDegrees = 360.0f; // puts sphere in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("black");
    SetShaderTexture("black");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawSphereMesh();
    /****************************************************************/
    /****************************************************************/
    //LAMP END
    /****************************************************************/
    /****************************************************************/

    /****************************************************************/
    /****************************************************************/
    //BOTTOM BOOK START
    /****************************************************************/
    /****************************************************************/
    // Box 1 (Back of Bottom Book)
    scaleXYZ = glm::vec3(1.6f, 0.1f, 2.1f);
    positionXYZ = glm::vec3(1.0f, 4.45f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book1");
    SetShaderTexture("book1");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 2 (Bottom Book Cover)
    scaleXYZ = glm::vec3(1.6f, 0.1f, 2.1f);
    positionXYZ = glm::vec3(1.0f, 4.74f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book1");
    SetShaderTexture("book1");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 3 (Bottom Book Spine)
    scaleXYZ = glm::vec3(0.1f, 0.3f, 2.1f);
    positionXYZ = glm::vec3(0.2f, 4.6f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book1");
    SetShaderTexture("book1");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 4 (Bottom Book Pages)
    scaleXYZ = glm::vec3(1.5f, 0.3f, 2.0f);
    positionXYZ = glm::vec3(1.01f, 4.6f, 0.0f);
    XrotationDegrees = 360.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("page");
    SetShaderTexture("page");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();
    /****************************************************************/
    /****************************************************************/
    //BOTTOM BOOK END
    /****************************************************************/
    /****************************************************************/

    /****************************************************************/
    /****************************************************************/
    //2ND BOTTOM BOOK START
    /****************************************************************/
    /****************************************************************/
    // Box 1 (Back of 2ND Bottom Book)
    scaleXYZ = glm::vec3(1.3f, 0.1f, 1.9f);
    positionXYZ = glm::vec3(1.2f, 4.85f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book2");
    SetShaderTexture("book2");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 2 (2ND Bottom Book Cover)
    scaleXYZ = glm::vec3(1.3f, 0.1f, 1.9f);
    positionXYZ = glm::vec3(1.2f, 5.1f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book2");
    SetShaderTexture("book2");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 3 (2ND Bottom Book Spine)
    scaleXYZ = glm::vec3(0.05f, 0.2f, 1.9f);
    positionXYZ = glm::vec3(0.55f, 5.0f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book2");
    SetShaderTexture("book2");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 4 (2ND Bottom Book Pages)
    scaleXYZ = glm::vec3(1.2f, 0.2f, 1.8f);
    positionXYZ = glm::vec3(1.2f, 5.0f, 0.0f);
    XrotationDegrees = 360.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("page");
    SetShaderTexture("page");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();
    /****************************************************************/
    /****************************************************************/
    //2ND BOTTOM BOOK END
    /****************************************************************/
    /****************************************************************/

    /****************************************************************/
    /****************************************************************/
    //3RD BOTTOM BOOK START
    /****************************************************************/
    /****************************************************************/
    // Box 1 (Back of 3RD Bottom Book)
    scaleXYZ = glm::vec3(1.3f, 0.1f, 2.0f);
    positionXYZ = glm::vec3(0.9f, 5.2f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book3");
    SetShaderTexture("book3");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 2 (3RD Bottom Book Cover)
    scaleXYZ = glm::vec3(1.3f, 0.1f, 2.0f);
    positionXYZ = glm::vec3(0.9f, 5.4f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book3");
    SetShaderTexture("book3");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 3 (3RD Bottom Book Spine)
    scaleXYZ = glm::vec3(0.05f, 0.2f, 2.0f);
    positionXYZ = glm::vec3(0.25f, 5.3f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book3");
    SetShaderTexture("book3");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 4 (3RD Bottom Book Pages)
    scaleXYZ = glm::vec3(1.2f, 0.2f, 1.9f);
    positionXYZ = glm::vec3(0.9f, 5.3f, 0.0f);
    XrotationDegrees = 360.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("page");
    SetShaderTexture("page");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();
    /****************************************************************/
    /****************************************************************/
    //3RD BOTTOM BOOK END
    /****************************************************************/
    /****************************************************************/

    /****************************************************************/
    /****************************************************************/
    //TOP BOOK START
    /****************************************************************/
    /****************************************************************/
    // Box 1 (Back of Top Book)
    scaleXYZ = glm::vec3(1.3f, 0.1f, 2.0f);
    positionXYZ = glm::vec3(1.3f, 5.5f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book4");
    SetShaderTexture("book4");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 2 (Top Book Cover)
    scaleXYZ = glm::vec3(1.3f, 0.1f, 2.0f);
    positionXYZ = glm::vec3(1.3f, 5.7f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book4");
    SetShaderTexture("book4");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 3 (Top Book Spine)
    scaleXYZ = glm::vec3(0.05f, 0.2f, 2.0f);
    positionXYZ = glm::vec3(0.65f, 5.6f, 0.0f);
    XrotationDegrees = 360.0f; // puts box in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("book4");
    SetShaderTexture("book4");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();

    // Box 4 (Top Book Pages)
    scaleXYZ = glm::vec3(1.2f, 0.2f, 1.9f);
    positionXYZ = glm::vec3(1.3f, 5.6f, 0.0f);
    XrotationDegrees = 360.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("page");
    SetShaderTexture("page");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawBoxMesh();
    /****************************************************************/
    /****************************************************************/
    //TOP BOOK END
    /****************************************************************/
    /****************************************************************/

    /****************************************************************/
    /****************************************************************/
    //COFFEE MUG START
    /****************************************************************/
    /****************************************************************/
    // Cylinder 1 (Base of Mug)
    scaleXYZ = glm::vec3(0.5f, 1.0f, 0.5f);
    positionXYZ = glm::vec3(1.3f, 5.75f, 0.0f);
    XrotationDegrees = 360.0f; // puts cylinder in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("cup");
    SetShaderTexture("cup");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawCylinderMesh();

    // Torus 1 (Mug Handle)
    scaleXYZ = glm::vec3(0.2f, 0.3f, 0.2f);
    positionXYZ = glm::vec3(1.9f, 6.3f, 0.0f);
    XrotationDegrees = 360.0f; // puts torus in upright position
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderMaterial("cup");
    SetShaderTexture("cup");
    SetTextureUVScale(1.0, 1.0);
    m_basicMeshes->DrawTorusMesh();

}